This is an effort to start a documentation for Zeos by collecting
various documentation files from various sources and putting them
in one big Zeos Manual.