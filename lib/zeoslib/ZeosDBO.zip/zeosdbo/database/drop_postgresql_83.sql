/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 8.3                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/

drop type if exists TEnumTest cascade;
drop table if exists extension;