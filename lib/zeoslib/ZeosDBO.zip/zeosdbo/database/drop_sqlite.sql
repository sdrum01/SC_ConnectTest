/*==============================================================*/
/* Database name:  SQLite                                       */
/* DBMS name:      SQLite 2.8                                   */
/* Created on:     04.02.2003 20:01:43                          */
/*==============================================================*/

drop view dep_view;
drop table blob_values;
drop table cargo;
drop table date_values;
drop table equipment2;
drop table equipment;
drop table number_values;
drop table people;
drop table department;
drop table string_values;
drop table not_null_values;
drop table [case_sensitive];
drop table high_load;
drop table default_values;
drop table default_values2;
drop table empty_types;
drop table "Spaced Names";

