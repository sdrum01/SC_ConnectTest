/*==============================================================*/
/* Database name:  zeoslib.gdb                                  */
/* DBMS name:      Interbase 6                                  */
/*==============================================================*/

DROP TRIGGER TRIGGER841559;
DROP TABLE TABLE789879;
DROP TABLE TABLE841559;
DROP TABLE TABLE865441;
DROP EXCEPTION EXCEPTION841559;
DROP TABLE TABLE864622;
DROP TABLE TABLE886914;
DROP TABLE TABLE886194;
DROP TABLE TABLE897631;
DROP TABLE TABLE909181;
DROP TABLE TABLE920450;
DROP TABLE TABLE1021705;
DROP TABLE TEST_DECIMAL;
DROP TRIGGER Ticket54_BI;
DROP GENERATOR Ticket54_GEN;
DROP TABLE Ticket54;
drop table PLUSA;
drop table PLUS__;
drop table Ticket192;
drop table TABLE1;
drop domain CURRENCY_D;
DROP TABLE TestTicket363;
DROP TABLE Ticket376a;
DROP TABLE Ticket376b;
DROP TABLE Ticket418;
