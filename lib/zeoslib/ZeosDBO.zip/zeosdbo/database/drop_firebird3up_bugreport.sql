drop table SF524;
