/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 11 and up                         */
/* Created on:     31.10.2019 04:15                             */
/*==============================================================*/

drop procedure if exists "PROC_ABTEST";
