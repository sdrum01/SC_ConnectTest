/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 7                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/


drop table if exists test815852;
drop table if exists xyz.test824780;
drop table if exists test824780;
drop schema if exists xyz;

drop domain if exists tinteger;
drop domain if exists tstring;
drop table if exists test1014416;