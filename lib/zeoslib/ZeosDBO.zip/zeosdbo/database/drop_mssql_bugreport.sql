DROP PROCEDURE proc907497
go

DROP PROCEDURE proc959307
go

DROP TABLE table959307
go

DROP TABLE mantis54
go

drop table national_char_values
go

drop table Mantis164
go

drop table TableTicked306
go