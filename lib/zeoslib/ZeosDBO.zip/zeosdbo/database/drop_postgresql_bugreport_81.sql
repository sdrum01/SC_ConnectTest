/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 7                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/

drop table if exists "RANMeter";


drop table if exists family;

drop table if exists clients;

drop domain if exists yesno;
