/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 7                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/

drop table if exists Mantis229;
drop table if exists ntax_bejovo_konyvelesi_tipusok;
drop table if exists Ticket51_A;
drop table if exists Ticket51_B;
drop table if exists test739514;
drop table if exists test739519;
drop table if exists test766053a;
drop table if exists test766053b;
drop table if exists test816846;

drop table if exists "insert";

drop table if exists test894367b;
drop table if exists test894367a;

drop table if exists sf354;