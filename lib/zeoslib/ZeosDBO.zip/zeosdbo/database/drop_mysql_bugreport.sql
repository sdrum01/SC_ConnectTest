/*==============================================================*/
/* Database name:  MySql                                        */
/* DBMS name:      MySQL 3.23                                   */
/* Created on:     04.02.2003 19:48:39                          */
/*==============================================================*/

drop table IF EXISTS table735226a;
drop table IF EXISTS table735226b;
drop table IF EXISTS Table726788;
drop table IF EXISTS table735299;
drop table IF EXISTS table735299_bit;
drop table IF EXISTS table740899;
drop table IF EXISTS table724542;
drop table IF EXISTS table739448a;
drop table IF EXISTS table739448b;
drop table IF EXISTS table733236;
drop table IF EXISTS table768163;
drop table IF EXISTS table799863;
drop table IF EXISTS table000001;
drop table IF EXISTS table817607;
drop table IF EXISTS table816925;
drop table IF EXISTS table828147;
drop table IF EXISTS table840608;
drop table IF EXISTS table849723;
drop table IF EXISTS table869609;
drop table IF EXISTS table865564;
drop table IF EXISTS table881634a;
drop table IF EXISTS table881634b;
drop table IF EXISTS table884135a;
drop table IF EXISTS table884135b;
drop table IF EXISTS table886841;
drop table IF EXISTS table894367a;
drop table IF EXISTS table894367b;
drop table IF EXISTS table894367c;
drop table IF EXISTS TableTicket52;
drop table IF EXISTS TableMS56OBER9357;
/*
drop table table914436;
*/
drop table IF EXISTS `Table 938705`;
drop table IF EXISTS table957126;
drop table IF EXISTS table987022;
drop table IF EXISTS table989474;
drop table IF EXISTS table1045286;
drop table IF EXISTS TableTicket240;
drop table IF EXISTS TableTicked389;

drop TRIGGER IF EXISTS TR_UPD_TableTicket304;
drop table if EXISTS TableTicket304;
drop table if exists biginterror;
