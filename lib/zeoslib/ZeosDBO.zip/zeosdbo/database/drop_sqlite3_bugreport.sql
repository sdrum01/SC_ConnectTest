/*==============================================================*/
/* Database name:  SQLite                                       */
/* DBMS name:      SQLite 3up                                   */
/* Created on:     05.11.2019 04:28:00                          */
/*==============================================================*/

drop table table_ticket_386;

drop table [TestSF431];

