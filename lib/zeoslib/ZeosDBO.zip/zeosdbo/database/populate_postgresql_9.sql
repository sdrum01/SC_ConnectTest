/*==============================================================*/
/* Database name:  zeoslib                                      */
/* DBMS name:      PostgreSQL                                   */
/* Created on:     28.12.2002 20:27:07                          */
/*==============================================================*/

INSERT INTO guid_test (id, guid) VALUES(1, '{BAD51CFF-F21F-40E8-A9EA-838977A681BE}');