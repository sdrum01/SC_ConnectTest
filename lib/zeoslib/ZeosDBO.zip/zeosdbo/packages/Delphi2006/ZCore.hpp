// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Zcore.pas' rev: 10.00

#ifndef ZcoreHPP
#define ZcoreHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Zvariant.hpp>	// Pascal unit
#include <Zcollections.hpp>	// Pascal unit
#include <Zcompatibility.hpp>	// Pascal unit
#include <Zencoding.hpp>	// Pascal unit
#include <Zexpression.hpp>	// Pascal unit
#include <Zexprparser.hpp>	// Pascal unit
#include <Zexprtoken.hpp>	// Pascal unit
#include <Zfastcode.hpp>	// Pascal unit
#include <Zmatchpattern.hpp>	// Pascal unit
#include <Zsysutils.hpp>	// Pascal unit
#include <Ztokenizer.hpp>	// Pascal unit
#include <Zvariables.hpp>	// Pascal unit
#include <Zclasses.hpp>	// Pascal unit
#include <Zmessages.hpp>	// Pascal unit
#include <Zurl.hpp>	// Pascal unit
#include <Zfunctions.hpp>	// Pascal unit
#include <Zfunctionsconvert.hpp>	// Pascal unit
#include <Zfunctionsdatetime.hpp>	// Pascal unit
#include <Zfunctionsmath.hpp>	// Pascal unit
#include <Zfunctionsother.hpp>	// Pascal unit
#include <Zfunctionsstrings.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zcore
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Zcore */
using namespace Zcore;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Zcore
