// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Zcomponentdesign.pas' rev: 10.00

#ifndef ZcomponentdesignHPP
#define ZcomponentdesignHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Zpropertyeditor.hpp>	// Pascal unit
#include <Zupdatesqleditor.hpp>	// Pascal unit
#include <Zcomponentreg.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Zfastcode.hpp>	// Pascal unit
#include <Zcompatibility.hpp>	// Pascal unit
#include <Zmessages.hpp>	// Pascal unit
#include <Zsysutils.hpp>	// Pascal unit
#include <Zgenericsqlanalyser.hpp>	// Pascal unit
#include <Zencoding.hpp>	// Pascal unit
#include <Zvariant.hpp>	// Pascal unit
#include <Zgenericsqltoken.hpp>	// Pascal unit
#include <Zdbcmetadata.hpp>	// Pascal unit
#include <Zdbclogging.hpp>	// Pascal unit
#include <Zdbcintfs.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Zdbcadoutils.hpp>	// Pascal unit
#include <Zdbcadometadata.hpp>	// Pascal unit
#include <Zdbcado.hpp>	// Pascal unit
#include <Zplaindblibdriver.hpp>	// Pascal unit
#include <Zdbcdblibmetadata.hpp>	// Pascal unit
#include <Zdbcdblib.hpp>	// Pascal unit
#include <Zdbcpostgresqlmetadata.hpp>	// Pascal unit
#include <Zdbcpostgresqlstatement.hpp>	// Pascal unit
#include <Zpostgresqlanalyser.hpp>	// Pascal unit
#include <Zdbcpostgresql.hpp>	// Pascal unit
#include <Zdbcinterbase6utils.hpp>	// Pascal unit
#include <Zdbcinterbase6metadata.hpp>	// Pascal unit
#include <Zdbcinterbase6.hpp>	// Pascal unit
#include <Zdbcsqliteresultset.hpp>	// Pascal unit
#include <Zdbcsqlitemetadata.hpp>	// Pascal unit
#include <Zsqliteanalyser.hpp>	// Pascal unit
#include <Zdbcsqlite.hpp>	// Pascal unit
#include <Zdbcoraclemetadata.hpp>	// Pascal unit
#include <Zoracleanalyser.hpp>	// Pascal unit
#include <Zdbcoracle.hpp>	// Pascal unit
#include <Zdbcasametadata.hpp>	// Pascal unit
#include <Zdbcasa.hpp>	// Pascal unit
#include <Zdbcpooled.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Widestrings.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Zexprparser.hpp>	// Pascal unit
#include <Zexprtoken.hpp>	// Pascal unit
#include <Zfunctionsconvert.hpp>	// Pascal unit
#include <Zdatasetutils.hpp>	// Pascal unit
#include <Zabstractrodataset.hpp>	// Pascal unit
#include <Zabstractconnection.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Proxies.hpp>	// Pascal unit
#include <Idemessages.hpp>	// Pascal unit
#include <Captioneddocktree.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Extdlgs.hpp>	// Pascal unit
#include <Mapi.hpp>	// Pascal unit
#include <Extactns.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Tabs.hpp>	// Pascal unit
#include <Docktabset.hpp>	// Pascal unit
#include <Percentagedocktree.hpp>	// Pascal unit
#include <Actnman.hpp>	// Pascal unit
#include <Actnmenus.hpp>	// Pascal unit
#include <Xpstyleactnctrls.hpp>	// Pascal unit
#include <Basedock.hpp>	// Pascal unit
#include <Deskutil.hpp>	// Pascal unit
#include <Deskform.hpp>	// Pascal unit
#include <Dockform.hpp>	// Pascal unit
#include <Msxmldom.hpp>	// Pascal unit
#include <Xmldom.hpp>	// Pascal unit
#include <Xmlintf.hpp>	// Pascal unit
#include <Toolsapi.hpp>	// Pascal unit
#include <Designeditors.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Zcomponentdesign
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Zcomponentdesign */
using namespace Zcomponentdesign;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Zcomponentdesign
